#internal imports
from . import Base
import numpy as np

class ReLU(Base.BaseLayer):
	def __init__(self):
		super(ReLU, self).__init__()
		self.old_input = None
		
	def forward(self, input_tensor):
		self.old_input = input_tensor
		new_input = np.maximum(np.zeros((len(input_tensor), len(input_tensor[0]) )  ), input_tensor)
		return new_input 
		
	def backward(self, error_tensor):
		new_input = np.multiply(error_tensor, self.old_input > 0) 
		return new_input

